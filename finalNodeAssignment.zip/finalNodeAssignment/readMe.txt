Nagarro Evaluation Project
 
Summary
 
Create a web app, where users can login with their email and password and manage a list of their favourite bands.
 
Required Functionality
 
User Authentication
Signup
Login
Add new band to the list
Remove a band from the list
Edit a band�s name from the list
A user may only manage his/her own list
 
User Authentication
Login with user�s email and password as credentials
New Users must have atleast the following fields (* means mandatory)
Name*
College/Company
Date Of Birth*
Email* 
 
Bonus Functionality
Adding these gets you extra points
Forgot Password Feature: A user can reset own password by confirming an OTP sent to his email. You can use npmjs.com/package/nodemailer or https://sendgrid.com/docs/API_Reference/index.html api to send emails.

 
 Format
Upload code to a Github repository
Send an email with link to source code
Note that commit message names, code cleanliness in Github
repo factors into marking scheme


Example Wireframe: https://wireframe.cc/IeI0JV